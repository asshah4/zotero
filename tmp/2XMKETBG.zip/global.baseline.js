(function($) {
	$(function() {
		$('.baseline-wrapper').baseline();
	});
})(jQuery);